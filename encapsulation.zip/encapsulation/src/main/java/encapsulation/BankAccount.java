
package encapsulation;


public class BankAccount {
    

    private String accountNumber;
    private double balance;
    private String accountHolderName;

    public BankAccount(String ac, double bal, String name) {
        setAccountNumber(ac);
        setBalance(bal);
        setAccountHolderName(name);
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String ac) {
        if (ac == null || ac.isEmpty()) {
            System.out.println("Invalid Account Number!");
        } else {
            this.accountNumber = ac;
        }
    }

    
    public double getBalance() {
        return balance;
    }

    public void setBalance(double bal) {
        if (bal < 0) {
            System.out.println("Balance cannot be negative!");
        } else {
            this.balance = bal;
        }
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String name) {
        if (name == null || name.isEmpty()) {
            System.out.println("Invalid Name!");
        } else {
            this.accountHolderName = name;
        }
    }

    public void deposit(double amountDeposit) {
        if (amountDeposit <= 0) {
            System.out.println("Invalid Amount! Enter a positive value.");
        } else {
            this.balance += amountDeposit;
            System.out.println("✅ Deposit Successful! Amount Deposited: " + amountDeposit);
        }
    }

    public void withdraw(double amountWithdrawal) {
        if (amountWithdrawal <= 0) {
            System.out.println("Invalid Withdrawal Amount!");
        } else if (amountWithdrawal > this.balance) {
            System.out.println("Insufficient Balance!");
        } else {
            this.balance -= amountWithdrawal;
            System.out.println("Successfully Withdrawn: " + amountWithdrawal);
        }
    }
}